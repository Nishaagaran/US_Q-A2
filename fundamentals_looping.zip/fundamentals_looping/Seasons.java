package Fundamentals;

import java.util.Scanner;

public class Seasons {

	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String month=sc.next();
		if(month.equals("dec")||month.equals("jan")||month.equals("feb"))
{
	System.out.println("winter");
}
		else if(month.equals("mar")||month.equals("apr")||month.equals("may"))
		{
			System.out.println("Spring");
		}
		else if(month.equals("jun")||month.equals("jul")||month.equals("aug"))
		{
			System.out.println("summer");
		}
		else if (month.equalsIgnoreCase("sep")||month.equals("oct")||month.equals("nov"))
		{
			System.out.println("autumn");
		}
		else
		{
			System.out.println("no such season");
		}
	}
}
