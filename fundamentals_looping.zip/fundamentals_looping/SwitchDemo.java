package Fundamentals;

import java.util.Scanner;

public class SwitchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String month=sc.next();
		
		switch(month)
		{
		case "jan":
		{
		System.out.println("winter");
		break;
		}
		case "feb":
			
		{
			System.out.println("winter");
			break;
		}
		case "mar":
		{
			System.out.println("spring");
			break;
		}
		case "apr":
			
		{
			System.out.println("spring");
			break;
		}
		case "may":
		{
			System.out.println("spring");
			break;
		}
		case "jun":
		{
			System.out.println("summer");
			break;
		}
		case "jul":
		{
			System.out.println("summer");
			break;
		}
		case "aug":
		{
			System.out.println("summer");
			break;
		}
		case "sep":
		{
			System.out.println("autum");
			break;
		}
		case "oct":
		{
			System.out.println("autum");
			break;
		}
		case "nov":
		{
			System.out.println("autum");
			break;
		}
		case "dec":
		{
			System.out.println("winter");
			break;
		}
	}

}
}
