import java.util.Scanner;

public class if_Demo {

	public static void main(String[] args) {
		int m, total_marks;
		// TODO Auto-generated method stub
//To use any clas we create object to invoke method
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		
		System.out.println(name);
		
		int m1=sc.nextInt();
		int m2=sc.nextInt();
		int m3=sc.nextInt();
		int m4=sc.nextInt();
		int m5=sc.nextInt();
		
		
total_marks=m1+m2+m3+m4+m5;
		System.out.println(total_marks);
		int average=(total_marks/5);
		System.out.println(average);
		if(average>90)
		{
			System.out.println("excellent");
		}
		else if ((average>=80)&&(average<=90))
		{
			System.out.println("very good");
		}
		else if((average>=70) && (average<80))
{
	System.out.println("good");
}
		else  if((average>=60)&& (average<70))
		{
			System.out.println("fair");
		}
		else
		{
			System.out.println("poor");
		}
	}

}
